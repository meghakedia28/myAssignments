/**
 * @author mindfire
 */
 $(document).ready( function() {
    $("#date").datepicker();
  } );